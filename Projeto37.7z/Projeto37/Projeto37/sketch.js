var canvas, backgroundImage;

var questions;

var question, contestant, quiz;


function setup(){
  canvas = createCanvas(850,400);
  database = firebase.database();
  quiz = new Quiz();
//chame o método start() dentro da classe quiz (questionário)
question = new Question();

}


function draw(){
  background("pink");

}
